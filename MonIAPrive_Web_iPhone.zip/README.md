# Mon IA Privée — version web pour iPhone

Cette version fonctionne dans Safari et peut être ajoutée à l'écran d'accueil. Elle stocke les fiches, photos et historiques dans le stockage local du navigateur. La génération de texte utilise l'API OpenRouter (Internet requis).

## Fonctionnalités
- Personnages avec nom, salutation, description jusqu'à 32 000 caractères et photo.
- Conversations par personnage et historique local.
- Instructions de personnalité et envoi des derniers messages pour garder le contexte.
- Export/import de sauvegarde JSON.
- Interface sombre adaptée à l'iPhone.

## Pour commencer sur iPhone seulement
1. Il faut publier `index.html` sur un hébergeur statique HTTPS. Un hébergement gratuit comme GitHub Pages est possible, mais la création du dépôt et le téléversement depuis un iPhone sont des étapes manuelles.
2. Ouvre l'adresse HTTPS du site dans Safari.
3. Va dans Réglages IA, crée une clé sur https://openrouter.ai/keys et colle-la dans l'application.
4. Le modèle `openrouter/free` sélectionne un modèle gratuit disponible, si accessible. Les quotas et la disponibilité varient.
5. Dans Safari, touche Partager → Ajouter à l'écran d'accueil → Ajouter. Apple explique la procédure ici : https://support.apple.com/guide/iphone/open-as-web-app-iphea86e5236/ios

## Limites et confidentialité
- Je n'ai pas déployé le site pour toi : il s'agit des fichiers à publier. Je ne peux pas créer un site public directement depuis ce chat.
- Les données locales restent dans le navigateur de cet iPhone, mais peuvent disparaître si les données du site sont effacées. Utilise Exporter une sauvegarde.
- Les appels IA transmettent la description du personnage et l'historique récent au fournisseur configuré. Ne mets pas de secrets personnels dans les personnages ou les conversations.
- La clé API est enregistrée localement dans Safari et utilisée depuis le navigateur. Cette architecture est adaptée à un prototype personnel mais n'est pas sûre pour un site public ou partagé. Ne partage pas l'URL si elle contient tes données et ne publie jamais cette clé dans du code accessible au public.
- Les modèles gratuits ont des limites de débit et peuvent être lents, indisponibles ou changer. OpenRouter annonce actuellement une limite gratuite de 50 requêtes par jour pour son niveau Free : vérifie les conditions à jour.
- Les conversations sauvegardées localement ne sont pas envoyées à un serveur de stockage par cette application; le contenu nécessaire à la réponse est envoyé au fournisseur IA au moment de chaque génération.
